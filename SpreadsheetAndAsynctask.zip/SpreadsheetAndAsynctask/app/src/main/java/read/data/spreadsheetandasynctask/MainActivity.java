package read.data.spreadsheetandasynctask;

import static read.data.spreadsheetandasynctask.Common.SPREAD_SHEET_URL;
import static read.data.spreadsheetandasynctask.Common.readAllDataFromSheet;
import static read.data.spreadsheetandasynctask.Common.uploadDataToGoogleSpreadSheet;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    Button btnInsertData, btnReadData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnReadData = (Button)findViewById(R.id.btnReadData);

        btnInsertData = (Button) findViewById(R.id.btnInsertData);
        btnInsertData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String url = SPREAD_SHEET_URL;
                String id = "1990";
                String name = "Kamal";
                String address = "Dhaka" ;
                String age = "30";

                uploadData(url, id, name, address, age);



            }
        });

        btnReadData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                        readAllData(SPREAD_SHEET_URL);

            }
        });

    }


    void  uploadData ( String url, String id, String name, String address, String age){

        class  InsertDataToSpreadsheet extends AsyncTask<Void, Void, Void>{

            ProgressDialog dialog ;
            String result = null;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                dialog = new ProgressDialog(MainActivity.this);
                dialog.setTitle("Please Wait....");
                dialog.setMessage("Your Data is Uploading To Spreadsheet...");
                dialog.show();

            }

            @Override
            protected Void doInBackground(Void... voids) {


                JSONObject jsonObject = uploadDataToGoogleSpreadSheet (  url,  id,  name,  address,  age );

                if(jsonObject!=null) {
                    System.out.println("Json obect is : " + jsonObject);

                    try {
                        result = jsonObject.getString("result");
                    } catch (JSONException e) {
                        System.out.println("JsonException : "+ e.getLocalizedMessage());
                    }
                } else  System.out.println("Json Object is Null : Connection To Spreadsheet Is Not Established. ");

                return null;
            }

            @Override
            protected void onPostExecute(Void unused) {
                super.onPostExecute(unused);

                if(dialog!=null&&dialog.isShowing())
                    dialog.dismiss();

                if(result!=null){
                    Toast.makeText(MainActivity.this, "Result Is : "+result , Toast.LENGTH_SHORT).show();

                }else {
                    Toast.makeText(MainActivity.this, "Nothing Found", Toast.LENGTH_SHORT).show();
                }


            }

        }


        new InsertDataToSpreadsheet().execute();


    }


    void  readAllData( String url){

        class ReadAllDataFromSpreadSheet extends AsyncTask<Void, Void, Void>{

            ProgressDialog dialog ;
            String result = null;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                dialog = new ProgressDialog(MainActivity.this);
                dialog.setTitle("Please Wait....");
                dialog.setMessage("All Data Downloading From Spreadsheet...");
                dialog.show();

            }

            @Override
            protected Void doInBackground(Void... voids) {


                JSONObject jsonObject = readAllDataFromSheet (  url );
                System.out.println("Json obect Raw : " + jsonObject);

                if(jsonObject!=null)
                    result = jsonObject.toString();

                return null;
            }

            @Override
            protected void onPostExecute(Void unused) {
                super.onPostExecute(unused);

                if(dialog!=null&&dialog.isShowing())
                    dialog.dismiss();

                if(result!=null){
                    Toast.makeText(MainActivity.this, "Result Is : "+result , Toast.LENGTH_SHORT).show();

                }else {
                    Toast.makeText(MainActivity.this, "Nothing Found", Toast.LENGTH_SHORT).show();
                }


            }

        }


        new ReadAllDataFromSpreadSheet().execute();


    }



}