package read.data.spreadsheetandasynctask;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

public class Common {

    public  static  final  String SPREAD_SHEET_URL = "https://script.google.com/macros/s/AKfycbwYHU_M32F1CrvdEWYGS4Qc8qeMamRkaNhxi8N_WLCMy4_Kn1JshDOXQQ7HRxJGzxofLg/exec";

    private  static Response response ;

    public  static JSONObject uploadDataToGoogleSpreadSheet ( String url, String id, String name, String address, String age ){

        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(url +"?action=insert&id="+id+"&name="+name+"&address="+address+"&age="+age)
                    .build();
            response = client.newCall(request).execute();

            return  new JSONObject(response.body().string());


        } catch (IOException |JSONException e ) {
           System.out.println("Receiving null : "+ e.getLocalizedMessage());
        }

        return  null ;
    }


    public  static JSONObject readAllDataFromSheet (String url){

        try {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder()
                    .url(url +"?action=read_all")
                    .build();
            response = client.newCall(request).execute();

           // System.out.println("REsponse: "+response.body().string());

            return  new JSONObject(response.body().string());


        } catch (IOException |JSONException e ) {
            System.out.println("Receiving null : "+ e.getLocalizedMessage());
        }

        return  null ;
    }


}
